/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       s.miles1313                                               */
/*    Created:      Fri Nov 01 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "pragma.h"

using namespace vex;


/*
vex::motor leftMotor(PORT1,gearSetting::ratio36_1,false);
vex::motor leftMotor2(PORT2,gearSetting::ratio36_1,false);
vex::motor rightMotor(PORT3,gearSetting::ratio36_1,true);
vex::motor rightMotor2(PORT4,gearSetting::ratio36_1,true);
vex::motor armMotorL(PORT5,gearSetting::ratio36_1,false);
vex::motor armMotorR(PORT6,gearSetting::ratio36_1,true);
vex::motor claw(PORT7,gearSetting::ratio36_1,false);
vex::motor claw2(PORT8,gearSetting::ratio36_1,true);
*/

/////////// CHASSIS ///////////
void chassisvel(int per)
{ 
  leftMotor.setVelocity( per, vex::velocityUnits::pct); 
  leftMotor2.setVelocity( per, vex::velocityUnits::pct);
  rightMotor.setVelocity( per, vex::velocityUnits::pct);
  rightMotor2.setVelocity( per, vex::velocityUnits::pct);
}

void chassisforward(int time)
{
  leftMotor.spin(vex::directionType::fwd);
  leftMotor2.spin(vex::directionType::fwd);
  rightMotor.spin(vex::directionType::fwd);
  rightMotor2.spin(vex::directionType::fwd);
  task::sleep(time);
}

void chassisbackward(int time)
{
  leftMotor.spin(vex::directionType::rev);
  leftMotor2.spin(vex::directionType::rev);
  rightMotor.spin(vex::directionType::rev);
  rightMotor2.spin(vex::directionType::rev);
  task::sleep(time);
}

void chassisturnright(int time)
{
  leftMotor.spin(vex::directionType::fwd);
  leftMotor2.spin(vex::directionType::fwd);
  rightMotor.spin(vex::directionType::rev);
  rightMotor2.spin(vex::directionType::rev);
  task::sleep(time);
}

void chassisturnleft(int time)
{
  leftMotor.spin(vex::directionType::rev);
  leftMotor2.spin(vex::directionType::rev);
  rightMotor.spin(vex::directionType::fwd);
  rightMotor2.spin(vex::directionType::fwd);
  task::sleep(time);
}

///////////// ARM //////////////
void armvel(int per)
{
  armMotorL.setVelocity( per, vex::velocityUnits::pct);
  armMotorR.setVelocity( per, vex::velocityUnits::pct);
}

void armup(int time)
{
  armMotorL.spin(vex::directionType::fwd);
  armMotorR.spin(vex::directionType::fwd);
  task::sleep(time);
}

void armdown(int time)
{
  armMotorL.spin(vex::directionType::rev);
  armMotorR.spin(vex::directionType::rev);
  task::sleep(time);
}

//////////// CLAW /////////////
void clawvel(int per)
{
  claw.setVelocity( per, vex::velocityUnits::pct);
  claw2.setVelocity( per, vex::velocityUnits::pct);
}

void clawopen(int time)
{
  claw.spin(vex::directionType::fwd);
  claw2.spin(vex::directionType::fwd);
  task::sleep(time);
}

void clawclose(int time)
{
  claw.spin(vex::directionType::rev);
  claw2.spin(vex::directionType::rev);
  task::sleep(time);
}

///////// ROTATIONS ///////////
void chassisturn(int leftrot,int rightrot, int time)
{
  leftMotor.rotateFor(leftrot, rotationUnits::deg, false);        //true or false for motors stopping after execution
  leftMotor2.rotateFor(leftrot, rotationUnits::deg, false);
  rightMotor.rotateFor(rightrot, rotationUnits::deg, false);
  rightMotor2.rotateFor(rightrot, rotationUnits::deg, false);
  task::sleep(time);
}

/////////// BRAKES ////////////
void chassisbrake(char time)
{
  leftMotor.stop(brakeType::brake);
  leftMotor2.stop(brakeType::brake);
  rightMotor.stop(brakeType::brake);
  rightMotor2.stop(brakeType::brake);
  task::sleep(time);
}

void armbrake(char time)
{
  armMotorL.stop(brakeType::brake);
  armMotorR.stop(brakeType::brake);
  task::sleep(time);
}

void clawbrake(char time)
{
  claw.stop(brakeType::brake);
  claw2.stop(brakeType::brake);
  task::sleep(time);
}

////////// HOLDS ///////////
void chassishold(char time)
{
  leftMotor.stop(brakeType::hold);
  leftMotor2.stop(brakeType::hold);
  rightMotor.stop(brakeType::hold);
  rightMotor2.stop(brakeType::hold);
  task::sleep(time);
}

void armhold(char time)
{
  armMotorL.stop(brakeType::hold);
  armMotorR.stop(brakeType::hold);
  task::sleep(time);
}

void clawhold(char time)
{
  claw.stop(brakeType::hold);
  claw2.stop(brakeType::hold);
  task::sleep(time);
}



//////////// MAIN ////////////

int main() {
  armvel(75);                   //arm velocity = 75
  armup(1500);

  clawhold(200);
  
  armdown(200);

  armbrake(200);
  armhold(200);

  /*
  chassisvel(75);                   //chassis velocity = 75
  chassisforward(1000);
  chassisbrake();
  armup(1000);
  armbrake();
  armhold();

  chassisvel(25);                   //chassis velocity = 25
  chassisforward(700);
  chassisbrake();
  chassishold();

  armvel(25);                   //arm velocity = 25
  armdown(500);
  armbrake();
  armhold();

  clawvel(50);                   //claw velocity - 50
  clawclose(1000);
  clawbrake();
  clawhold();

  armup(500);
  armbrake();
  armhold();
  */

  chassisforward(2000); //to 4-stack

  chassisbrake(200);

  armvel(50);                   //arm velocity = 50
  armup(1000);

  armbrake(200);
  armhold(200);

  chassisvel(25);                   //chassis velocity = 25
  chassisforward(500);

  chassisbrake(200);
  chassishold(200);

  armvel(25);                   //arm velocity = 25
  armdown(200);

  armbrake(200);
  armhold(200);

  clawvel(50);                   //claw velocity = 50
  clawopen(1500);

  clawbrake(200);

  armdown(1000);
  
  armbrake(200);
  armhold(200);

  clawclose(700);

  clawbrake(200);
  clawhold(200);

  armup(300);

  armbrake(200);
  armhold(200);
  
  chassisbackward(1500);

  chassisbrake(200);

  chassisturnright(2500);

  chassisbrake(200);
  chassisvel(45);                   //chassis velocity = 45
  chassisforward(1000);

  chassisbrake(200);
  
  armdown(300);

  clawopen(750);

  chassisbackward(4000);

  //chassisturnleft(700);

 }