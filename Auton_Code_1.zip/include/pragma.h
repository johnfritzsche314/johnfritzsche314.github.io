#include <vex.h>
using namespace vex;

vex::motor leftMotor(PORT1,gearSetting::ratio36_1,false);
vex::motor leftMotor2(PORT2,gearSetting::ratio36_1,false);
vex::motor rightMotor(PORT3,gearSetting::ratio36_1,true);
vex::motor rightMotor2(PORT4,gearSetting::ratio36_1,true);
vex::motor armMotorL(PORT5,gearSetting::ratio36_1,false);
vex::motor armMotorR(PORT6,gearSetting::ratio36_1,true);
vex::motor claw(PORT7,gearSetting::ratio36_1,false);
vex::motor claw2(PORT8,gearSetting::ratio36_1,true);